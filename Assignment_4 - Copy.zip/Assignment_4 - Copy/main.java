//run this file to start a game
public class main
{
   public static void main(String args[]){ 
      user tim=new user();
   }
}
