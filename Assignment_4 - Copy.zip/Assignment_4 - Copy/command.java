public interface command{
   public void execute();
}